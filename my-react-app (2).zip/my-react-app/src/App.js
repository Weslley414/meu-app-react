// src/App.jsx
import { useState } from "react";
import './App.css';
import Header from './components/Header';
import Banner from './components/Banner';
import Contanner from './components/Contanner';
import Footer from './components/Footer';

function App() {

  // 🔍 Estado que guarda o texto digitado na busca
  const [search, setSearch] = useState("");

  return (
    <>
      {/* Envia a função para o Header */}
      <Header onSearch={setSearch} />

      {/* Envia o texto da busca para o Banner */}
      <Banner search={search} />

      <Contanner />
      <Footer />
    </>
  );
}

export default App;
