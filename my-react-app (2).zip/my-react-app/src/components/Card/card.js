import styles from './Card.module.css';
// Importa o arquivo CSS Module, garantindo que as classes sejam únicas para este componente.

// Componente Card que recebe três propriedades: title, description e image
function Card({ title, description, image }) {
  return (
    // Container principal do card
    <div className={styles.card}>

      {/* Renderiza a imagem SOMENTE se a prop "image" existir */}
      {image && (
        <img 
          src={image}           // caminho da imagem
          alt={title}           // texto alternativo acessível
          className={styles.image} // estilização da imagem
        />
      )}

      {/* Título do card */}
      <h3 className={styles.title}>{title}</h3>

      {/* Descrição do card */}
      <p className={styles.description}>{description}</p>

      {/* Botão padrão do card */}
      <button className={styles.button}>
        Saiba mais
      </button>
    </div>
  );
}

export default Card;
// Exporta o componente para ser usado em outros arquivos.
