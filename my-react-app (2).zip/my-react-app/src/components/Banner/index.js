import styles from './Banner.module.css'

export default function Banner({ search = "" }) {

  const integrantes = [
    { id: 1, img: '/integrante1.png', nome: "Integrante 1", videoUrl: 'https://youtu.be/3U-1nWAnPu8?si=XreQOfi5hxqSEhRq'},
    { id: 2, img: '/integrante2.png', nome: "Integrante 2", videoUrl: 'https://youtu.be/q70AXhpJiDc?si=j9mQDV-mptvBRGjN'},
    { id: 3, img: '/integrante3.png', nome: "Integrante 3", videoUrl: 'https://youtu.be/ZXGSQxRHxgU?si=2PyhfE3pbs-zkfGv'},
    { id: 4, img: '/integrante4.png', nome: "Integrante 4", videoUrl: 'https://youtu.be/imhuY_r1B4s?si=fN7S14-MD6QQcGNh'},
    { id: 5, img: '/integrante5.png', nome: "Integrante 5", videoUrl: 'https://youtu.be/ul8mL2-GlmY?si=aKtGfserp_EIq_CP'},
    { id: 6, img: '/integrante6.png', nome: "Integrante 6", videoUrl: 'https://youtu.be/Quhl3QhU7o0?si=zak_lSu3XkrXk-Pc'},
  ];

  // 🔍 Filtra pelo texto digitado
  const filtrados = integrantes.filter(item =>
    item.nome.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className={styles.banner}>
      <div className={styles.box}>

        <div className={styles.hero}>
          <div className={styles.titleBar}>
            <span className={styles.title}>Integrantes</span>
          </div>
        </div>

        <section className={styles.integrantesSection}>
          <div className={styles.grid}>

            {filtrados.length === 0 && (
              <p style={{ color: "white", fontSize: "20px" }}>
                Nenhum integrante encontrado.
              </p>
            )}

            {filtrados.map(item => (
              <article key={item.id} className={styles.card}>
                <div className={styles.thumbWrap}>
                  <a 
                    href={item.videoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <img 
                      src={item.img}
                      alt={item.nome}
                      className={styles.thumb}
                      loading="lazy"
                    />
                  </a>

                  {/* Nome opcional */}
                  <p style={{ color: "white", textAlign: "center", marginTop: "10px" }}>
                    {item.nome}
                  </p>
                </div>
              </article>
            ))}

          </div>
        </section>
      </div>
    </div>
  )
}
