import styles from './Contanner.module.css';
// Importa o arquivo de estilos CSS Modules, garantindo classes exclusivas.

// Componente principal
export default function Contanner() {

  // Dados da árvore genealógica da Família Real
  const family = [
    {
      name: 'Rei Charles III',
      birth: '14/11/1948',
      img: '/charles.jpg',
      children: [
        {
          name: 'Príncipe William',
          birth: '21/06/1982',
          img: '/william.jpg',
          children: [
            { name: 'Príncipe George', birth: '22/07/2013', img: '/george.jpg' },
            { name: 'Princesa Charlotte', birth: '02/05/2015', img: '/charlotte.jpg' },
            { name: 'Príncipe Louis', birth: '23/04/2018', img: '/louis.jpg' },
          ],
        },
        {
          name: 'Príncipe Harry',
          birth: '15/09/1984',
          img: '/harry.jpg',
          children: [
            { name: 'Príncipe Archie', birth: '06/05/2019', img: 'archie.jpg' },
            { name: 'Princesa Lilibet', birth: '04/06/2021', img: 'lilibet.jpg' },
            { name: 'Príncipe Wendre', birth: '01/01/2020', img: 'wendre.jpg' } // novo membro
          ],
        },
      ],
    },
  ];

  // Componente interno que representa cada nó da árvore genealógica.
  // Ele é recursivo: se a pessoa tiver filhos, ele chama TreeNode novamente.
  function TreeNode({ person }) {
    return (
      <li className={styles.treeItem}>

        {/* Bloco principal do membro */}
        <div className={styles.node}>

          {/* Foto do familiar */}
          <img 
            src={person.img} 
            alt={person.name} 
            className={styles.avatar} 
          />

          {/* Nome e data de nascimento */}
          <div className={styles.nodeText}>
            <div className={styles.nodeName}>{person.name}</div>
            <div className={styles.birth}>{person.birth}</div>
          </div>
        </div>

        {/* Caso essa pessoa tenha filhos, renderiza uma lista deles */}
        {person.children && person.children.length > 0 && (
          <ul className={styles.children}>
            {person.children.map(child => (
              
              // Chamada recursiva: TreeNode renderiza TreeNode
              <TreeNode key={child.name} person={child} />
            ))}
          </ul>
        )}
      </li>
    );
  }

  return (
    <section className={styles.categoria}>
      
      {/* Barra decorativa amarela */}
      <div className={styles.yellowBar} />

      <div className={styles.container}>
        <div className={styles.contentBox}>

          {/* Cabeçalho da seção */}
          <header className={styles.titleBar}>
            <span className={styles.title}>Linha de Sucessão</span>
          </header>

          <div className={styles.body}>
            
            {/* Texto descritivo (vazio no momento) */}
            <p className={styles.description}></p>

            {/* Container da árvore genealógica */}
            <div className={styles.familyWrapper}>
              <ul className={styles.tree}>

                {/* Renderiza o "tronco" da árvore — cada raiz do array family */}
                {family.map(root => (
                  <TreeNode key={root.name} person={root} />
                ))}

              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
