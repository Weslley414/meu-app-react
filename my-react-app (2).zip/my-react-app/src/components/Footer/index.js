import styles from './Footer.module.css';
// Importa o arquivo de estilos CSS Modules, garantindo classes exclusivas.

// Componente de rodapé (footer)
function Footer() {
  return (
    // Elemento semântico <footer>, com classe de estilização
    <footer className={styles.footer}>

      {/* Bloco com informações do responsável e data */}
      <div className={styles.info}>
        <p>
          <strong>Responsável:</strong> José Wesley (Desenvolvedor Front-end)
        </p>
        <p>
          <strong>Última atualização:</strong> 11/11/2025
        </p>
      </div>

      {/* Bloco contendo ícones diversos */}
      <div className={styles.icons}>
        {/* Ícones simples sem interação, apenas exibidos visualmente */}
        <img src="email.png" alt="Email" />
        <img src="whatsapp.png" alt="WhatsApp" />
        <img src="calendar.png" alt="Calendário" />
        <img src="security.png" alt="Segurança" />
        <img src="info.png" alt="Informações" />
      </div>

      {/* Texto de direitos autorais */}
      <p className={styles.copy}>
        © 2025 Todos os direitos reservados.
      </p>
    </footer>
  );
}

export default Footer;
// Exporta o componente para ser usado em outros arquivos do projeto.
